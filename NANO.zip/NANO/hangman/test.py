inp=input()
print('inp:',repr(inp))
if repr(inp)==repr('\x1b'):
    print('esc')