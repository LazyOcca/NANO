import pathlib,random

wordListPath = str(pathlib.Path(__file__).parent.resolve())+'/wordlists'
wordList = open(wordListPath+'/OED/OxfordEnglishDictionary.txt').read().split("\n")
wordDict = {}
alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
decabet = ['1','2','3','4','5','6','7','8','9','0']


wordDict=dict((k.lower(),v) for row in wordList for k,v in [row.split('|')])

wrongList=[]
for word,meaning in wordDict.items():
    for l in word:
        if l in alphabet:continue
        else: 
            # print(f"{word}: {meaning}")
            break
    else:
        continue
    # print(word)
    wrongList.append(word)
# print(wrongList)  

for word in wrongList:
    wordDict = {'*'+word if k == word else k: v for k, v in wordDict.items()}



# wordListFile=''
# for word in wordDict:
#     wordListFile = wordListFile+f"{word}|{wordDict[word]}\n"
# wordListFile=wordListFile.rstrip("\n")

# open(wordListPath+'/OED/OxfordEnglishDictionary.txt',"w").write(wordListFile)
