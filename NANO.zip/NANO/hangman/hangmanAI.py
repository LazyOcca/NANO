import pathlib,random,os

class debug():
    showAnalyze=0      #1=giveFeedback
    showLetterCounts=2 #1=allLetterCounts 2=relevantLetterCounts
    showWordList=2     #1=wordList        2=len(wordList)

filePath=os.path.dirname(os.path.abspath(__file__))
eprintpath = filePath+'/wordlists/eprint/eprint.txt'
with open(eprintpath,"w") as e:pass
def eprint(txt:str='',end:str='\n'):
    with open(eprintpath,"a") as eprint:
        eprint.write(str(txt)+end)

def enput(text=""):
    inp=input(text)
    if repr(inp)==repr('\x1b'):exit()
    return inp

def intput(text="",default=0): 
    inp=enput(text)
    if not inp.isdigit(): inp=default
    return int(inp)

def removeLast(lst:list,remove:str):
    lst=lst[::-1]
    lst.remove(remove)
    return lst[::-1]

def removeDisabled(wordList):
    return [word for word in wordList if word[0] != '*']

allLetterCounts={}
guessedLetters=[]
alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
fullWordDict = dict(i.split('|') for i in open(str(pathlib.Path(__file__).parent.resolve())+'/wordlists/OED/OxfordEnglishDictionary.txt').read().split('\n')) #list from https://github.com/dwyl/english-words I also simplied their code
fullWordList = list(fullWordDict)
longestWordLetterCount=len(sorted(fullWordList,key=len)[-1])

def analyzeWordList(wordList:list,giveFeedback:bool=False):
    wordListLength = len(wordList)
    letterCounts = {}
    for letter in alphabet:
        letterCounts[letter]=0
    for currentWordCount,currentWord in enumerate(wordList):
        currentWord=currentWord.lower()
        for currentLetter in currentWord:
            letterCounts[currentLetter]+=1
        if giveFeedback: print(f"[{currentWordCount}/{wordListLength}]{currentWord}")
    return letterCounts

def possibleWords(wordState:list=['_'],fullWordList:list=fullWordList):
    wordList=[]
    wordLength=len(wordState)
    for word in fullWordList:
        if len(word)==wordLength:
            try:
                for stateLetter,wordLetter in zip(wordState,word):
                    if stateLetter not in ['_',wordLetter]:raise
            except:pass
            else:wordList.append(word)
    return wordList

def sortedRelevantLetterCounts(allLetterCounts:list=allLetterCounts , guessedLetters:list=guessedLetters):
    relevantLetterCounts=allLetterCounts
    for countedLetter in list(allLetterCounts):
        if (countedLetter in guessedLetters) or (allLetterCounts[countedLetter]==0):
            relevantLetterCounts.pop(countedLetter)
    return allLetterCounts

fullWordList = removeDisabled(fullWordList)

hs=0
isChangeSettings=True
yesList = ['true','1','yes','yep','o','y','ye','yea','yeah','ya',*['ya'+'s'*s for s in range(10)]]
while True: #loops/game
    wordList = fullWordList[:]
    if isChangeSettings:
        isAI = enput("Enable AI? ").lower() in yesList
        if isAI: isAIFullyAuto = enput("Want AI to be fully automatic? ").lower() in yesList
        else: isAIFullyAuto=False
        if isAIFullyAuto: isAutoRepeat = enput("Want AI to restart games automaticly? (epilepsy warning) ").lower() in yesList
        else: isAutoRepeat=False
        isCustomWord=enput("Choose your own word? ") in yesList
        if isCustomWord: theWord=enput("What do you want the word to be? ").lower()
        maxLives=intput("How many lives do you want? (default is 10) ",10)
    
    if wordList: 
        if not isCustomWord:
            theWord=fullWordList.pop(random.randint(0,len(fullWordList)-1)) 
            #theWord=fullWordList.pop(0) to do in alphabetacal order
    else: 
        print('\nYou guessed all the words! ...why? you ok?\n')
        exit()

    wordState = ["_"]*len(theWord)
    guessedLetters = []
    wordList = possibleWords(wordState,wordList)
    allLetterCounts = analyzeWordList(wordList,debug.showAnalyze)
    relevantLetterCounts = sortedRelevantLetterCounts(allLetterCounts,guessedLetters)

    lives=maxLives
    isPeekMode = isAI
    isGameOver = False
    hasWon = False
    print()
    while not isGameOver: #loops/turn
        if isAI:
            wordList = possibleWords(wordState,wordList)
            allLetterCounts = analyzeWordList(wordList,debug.showAnalyze)
            relevantLetterCounts = sortedRelevantLetterCounts(allLetterCounts,guessedLetters)
            mostLikelyLetter = sorted(relevantLetterCounts,key=relevantLetterCounts.get,reverse=True)[0]

            if debug.showLetterCounts==1:
                print(end="|")
                for l in allLetterCounts:
                    print(f"{l}:{allLetterCounts[l]}",end="|")
                print()
            elif debug.showLetterCounts==2:
                print(end="|")
                for l in sorted(relevantLetterCounts,key=relevantLetterCounts.get,reverse=True):
                    print(f"{l}:{relevantLetterCounts[l]}",end="|")
                print()
            if debug.showWordList==1:
                for word in wordList:
                    print(word,end=', ')
                print()
            if debug.showWordList==2:
                print(len(wordList),'matching words found.')

        print(f"you have {lives} {'lives left.' if lives > 1 else 'life left!'}")
        print("You've guessed the following letters:\n", ', '.join(letter.upper() for letter in guessedLetters))
        print(' '+' '.join(wordState).upper(),f" ({len(wordState)} letters long)")
        print(('('+' '.join(theWord)+')\n').upper() if isPeekMode else "",end='')
        
        if not isAI:
            guessedLetter = (enput("Guess a letter: ")+'-').lower()[0]
        elif not isAIFullyAuto: 
            enput(f"Guess a letter: {mostLikelyLetter}")
            guessedLetter = mostLikelyLetter
        else:
            print(f"Guess a letter: {mostLikelyLetter}")
            guessedLetter = mostLikelyLetter
        
        
        if guessedLetter not in alphabet:
            print('\n\nYou must guess a letter!')
            continue
        elif guessedLetter in guessedLetters:
            print(f'\n\nYou have already guessed {guessedLetter.upper()}!')
            continue
        else: 
            guessedLetters.append(guessedLetter)

        if guessedLetter not in theWord:
            lives-=1
        if lives<=0: 
            isGameOver=1


        wordState=[wordLetter if wordLetter in guessedLetters else "_" for wordLetter in theWord]

        if not "_" in wordState: 
            isGameOver=hasWon=1

        print('\n')

    if hasWon:
        print(f"You won!!! You had {lives} {'lives' if lives > 1 else 'life'} left.\nThe word was \033[1m{theWord}\033[0m.\nDefinition: {fullWordDict[theWord]}")
    else:
        print(f"Ahh you lost. \nThe word was {theWord}.\nDefinition: {fullWordDict[theWord]}")

    ## play again? ##
    if isAutoRepeat:
        isChangeSettings=False
    else:
        if enput("\nWant to play again? ") in yesList:
            isChangeSettings = enput("Want to change the settings? ") in yesList
        else:
            break

    ## Data Analyzation ##
    # score=maxLives-lives
    # eprint(f"{score}|{theWord}|{len(guessedLetters)}|{repr(guessedLetters)[1:-1].replace("'",'').replace('"','')}")
    
    print()