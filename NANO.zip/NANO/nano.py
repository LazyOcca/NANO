import os,subprocess,sys,termios,tty,time

def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)



filePath=os.path.dirname(os.path.abspath(__file__))
time.sleep(1)
clear="\033[1;1H\033[2J" 

games={'Number Guesser':'/number guesser/numberGuesser.py',
       'Hangman':'/hangman/hangmanAI.py',
       'Snake':'/snake/snake.py',
       'Nano Paint':'/nano paint/drawer.py'
       }

while 1:
    choices=[]
    print(f'{clear}Welcome to the NANO Appstore!\nWhat game do you want to play?\n')
    for n,game in enumerate(games,1):
        print(f' [{n}]{game}')
        choices.append(str(n))
    print()

    key=''
    while key not in choices:
        key=get_key()

    progPath=games[list(games)[int(key)-1]]

    print(clear)
    subprocess.run(["/usr/local/bin/python3",f"{filePath}{progPath}"])




print('done')