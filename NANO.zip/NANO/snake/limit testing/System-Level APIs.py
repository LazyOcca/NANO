import tkinter as tk
import re

# Function to apply ANSI color codes
def apply_ansi_codes(text_widget, text):
    # Define ANSI color codes
    ansi_escape = re.compile(r'\x1b\[(\d+)(;\d+)*m')

    # Colors mapping
    colors = {
        '30': 'black',
        '31': 'red',
        '32': 'green',
        '33': 'yellow',
        '34': 'blue',
        '35': 'magenta',
        '36': 'cyan',
        '37': 'white',
        '0': 'black'  # Reset color
    }

    # Reset color to default
    current_color = 'black'
    
    # Split text into segments and interpret ANSI codes
    segments = ansi_escape.split(text)
    for segment in segments:
        if segment:  # Check if the segment is not None or empty
            # Check if it is an ANSI code
            if segment.startswith('\x1b['):  # Found an ANSI code
                # Get the color code
                codes = segment[2:-1].split(';')  # Extract the codes
                current_color = colors.get(codes[0], 'black')  # Default to black if code not found
            else:
                # Insert text with the current color
                text_widget.insert(tk.END, segment, (current_color,))

# Sample text with ANSI escape codes
sample_text = "\x1b[31mThis is red text.\x1b[0m \x1b[32mThis is green text.\x1b[0m"

# Create the main window
root = tk.Tk()
root.title("ANSI Escape Codes in Tkinter")

# Create a Text widget
text_widget = tk.Text(root, wrap=tk.WORD, height=10, width=50)
text_widget.pack(pady=10)

# Configure text tags for colors
for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']:
    text_widget.tag_configure(color, foreground=color)

# Apply ANSI escape codes to the text widget
apply_ansi_codes(text_widget, sample_text)

# Start the Tkinter event loop
root.mainloop()
