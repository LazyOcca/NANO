import os,random

class Snake():
    def __init__(self):
        self.x=0
        self.y=0
        self.xy=(self.x,self.y)
        self.direction='right'
        self.tail=(31,127,31)
        self.head=(0,255,31)
        self.length=50
        self.path=[self.xy]
        self.isFade=True

class Route(Snake):
    def __init__(self):
        super().__init__()
        self.head=(55,75,55)
        self.tail=(180,185,180)
        self.length=50
        self.path=[]

filePath=os.path.dirname(os.path.abspath(__file__))

eprintpath = filePath+'/eprint/eprint.txt'
with open(eprintpath,"w") as e:pass

def eprint(txt:str='',end:str='\n'):
    with open(eprintpath,"a") as eprint:
        eprint.write(str(txt)+end)

def goto(xy:tuple[int,int]):
    x,y=xy
    print(f'\033[{y+1};{x+1}H',end='')

def drawAt(char:str,xy:tuple[int,int]):
    goto(xy)
    print(char,end='')
    goto((0,0))
    print('\0')

def drawPixelAt(rgb:tuple[int,int,int],xy:tuple[int,int],content:str='  '):
    x,y=xy
    x*=2
    if rgb is None:
        pixel=content
    else: 
        pixel=f'\033[48;2;{rgb[0]};{rgb[1]};{rgb[2]}m{str(content).rjust(2," ")}\033[0m'
    drawAt(pixel,(x,y))

def generateField(fieldXY:tuple[int,int],offsetXY:tuple[int,int]=(0,0)):
    offsetX,offsetY=offsetXY
    field=[]
    for fieldX in range(fieldXY[0]):
        for fieldY in range(fieldXY[1]):
            field.append((fieldX+offsetX,fieldY+offsetY))
    return field

def drawField(field):
    for xy in field:
        drawFieldTile(xy)

def drawFieldTile(xy):
    x,y=xy
    content=' '
    if (x+y)%2:
        tint=20
    else: tint=30
    if not (x and y):
        tint*=3
        if x==0: content=y
        elif y==0: content=x
    tileColor=(tint,tint,tint)
    drawPixelAt(tileColor,(x,y),content)

def drawSnake(snake,drawHead=True):
    if len(snake.path)>1:
        if snake.isFade:
            snakeSize=len(snake.path)
            for c,(s,p) in enumerate(zip(range(snakeSize),snake.path)):
                r,g,b=[int(round(snake.tail[i]+(((snake.head[i]-snake.tail[i])/(snakeSize-1))*s),0)) for i in range(3)]
                drawPixelAt((r,g,b),p,c)    
        else:
            drawPixelAt(snake.tail,snake.path[-2])
        # if len(snake.path)>snake.length:
        #     drawFieldTile(snake.path[0])
        #     del snake.path[0]
        # if drawHead:
        #     drawPixelAt(snake.head,snake.path[-1])

def drawList(lst,rgb,content='  '):
    for xy in lst:
        drawPixelAt(rgb,xy,content)

def drawApple(appleXY):
    drawPixelAt((255,0,0),appleXY,"\u0358 ")

def posneg(value):
    return -1 if value<0 else 1

def adjacent(curXY):
    curX,curY=curXY                                #up     right down  left
    return [(curX+tarX,curY+tarY) for tarX,tarY in [(0,-1),(1,0),(0,1),(-1,0)]]

def relative(xy,ab):
    (x,y),(a,b)=xy,ab
    return (x-a,y-b)

def translate(xy,ab):
    (x,y),(a,b)=xy,ab
    return (x+a,y+b)

def distance(xy,ab):
    (x,y),(a,b)=xy,ab
    return (abs(x-a)+abs(y-b))

class Path():
    def line(axis,startXY,stop,fix,step):
        path=[]
        startX,startY=startXY
        if axis=='x':
            for x in range(startX,stop,step):
                path.append((x,fix))
            return path
        else:
            for y in range(startY,stop,step):
                path.append((fix,y))
            return path

    def shortest(startXY,goalXY,direction):
        startX,startY=startXY
        goalX,goalY=goalXY
        dx,dy=goalX-startX,goalY-startY
        stepX=posneg(dx)
        stepY=posneg(dy)
        path=[]
        if direction=='x':
            path+=Path.line('x',startXY,goalX,startY,stepX)
            path+=Path.line('y',startXY,goalY,goalX,stepY)
        else: #=='y'
            path+=Path.line('y',startXY,goalY,startX,stepY)
            path+=Path.line('x',startXY,goalX,goalY,stepX)

        path.append(goalXY)
        return path

def crumble():
    pass

def ft(*tup):#frozen tuple = a tuple in a frozen set
    return frozenset({tup})

class AI():
    def findTarget(tarXY,curXY,step=0,route=[],breadCrumbs={}):
        # eprint(f'{1}')
        isFinished=curXY==tarXY
        step+=1
        route=route[:]
        crumb=breadCrumbs.setdefault(curXY,'free')
        # eprint(f'\n{step}|{crumb}:')
        if isFinished: return route,isFinished
        if crumb!='free' and step<crumb:
                if curXY in route:
                    route.remove(curXY)
                crumb='free'
        if step>18:
            # eprint("step too big")
            pass
        elif crumb=='free':
            route.append(curXY)
            breadCrumbs[curXY]=step
            # eprint(f'{route}\n{breadCrumbs}')

            nodes={}
            for nodeXY in adjacent(curXY):
                nodes[nodeXY]=distance(nodeXY,tarXY)

            nodes=[i for i in nodes if nodes[i]==min(nodes.values())]


            for nodeXY in nodes:
                route,isFinished=AI.findTarget(tarXY,nodeXY,step,route,breadCrumbs)

        elif step>crumb:
            # eprint("found bigger crumb")
            pass
        return route,isFinished


# breadCrumbs={ft(2,2):4,ft(1,2):1,ft(1,3):38,ft(1,4):8}
breadCrumbs={}

print('\033[2J')
drawField(generateField((17,17)))

key=''
while key!='E':
    start=(12,9)
    drawPixelAt((0,255,0),start)
    finish=(5,5)
    drawPixelAt((255,0,0),finish)


    route=Route()
    route.path,isFinished=AI.findTarget(finish,start)
    drawSnake(route)

    goto
    input('yo')

# eprint(f"\n\n{route.path}")




    
    





goto((10000,0))
input()
