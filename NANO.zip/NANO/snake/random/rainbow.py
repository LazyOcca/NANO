import time,math,random,os

def shiftList(lst:list,amount:int=1):
    amount %= len(lst)
    return lst[amount:]+lst[:amount]

def generateRainbow(size):
    rainbow=[]
    rgb=(255,0,0)
    fakeSize=math.ceil(size/6)
    grade=fakeSize
    scale=(255)/grade
    for s in [(0 ,1 ,0 ),(-1,0 ,0 ),(0 ,0 ,1 ),(0 ,-1,0 ),(1 ,0 ,0 ),(0 ,0 ,-1)]:
        s=(s[0]*scale,s[1]*scale,s[2]*scale)
        for g in range(grade):
            rainbow.append((int(rgb[0]),int(rgb[1]),int(rgb[2])))
            rgb=(rgb[0]+s[0],rgb[1]+s[1],rgb[2]+s[2])
    return rainbow[:size]




### JUST A RAINBOW ###
# rainbow=generateRainbow(200)
# print(rainbow)
# for color in rainbow:
#     print(f'\033[48;2;{int(color[0])};{int(color[1])};{int(color[2])}m  \033[0m',end='')


# # ## SPACING RAINBOW ###
# rainbow=generateRainbow(200)
# print(len(rainbow))
# shift=1
# for i in range(10000):
#     rainbow=generateRainbow(96)
#     shift+=int(-(math.sin(math.radians(i))*3)**1)
#     # shift-shift/2
#     rainbow=shiftList(rainbow,shift)
#     rainbow=rainbow[::-1]+rainbow
#     for i in range(166):
#         color=rainbow[0]
#         print(f'\033[48;2;{int(color[0])};{int(color[1])};{int(color[2])}m  \033[0m',end='')
#         rainbow=shiftList(rainbow,random.randint(1,1))
#     print()
#     time.sleep(0.003)



### SPACING ORB ###
class Orb:#mostly made by chatGPT
    def __init__(self, x, y, screen_width, screen_height, speed=2):
        self.x = x
        self.y = y
        self.x_velocity = random.uniform(-1, 1)
        self.y_velocity = random.uniform(-1, 1)
        self.speed = speed
        self.screen_width = screen_width
        self.screen_height = screen_height

    def update_position(self):
        # Update the position based on velocity
        self.x += self.x_velocity * self.speed
        self.y += self.y_velocity * self.speed

        # Slightly adjust x and y velocities to add randomness
        self.x_velocity += random.uniform(-0.1, 0.1)
        self.y_velocity += random.uniform(-0.1, 0.1)

        # Limit velocities so they don't become too fast
        self.x_velocity = max(-1, min(1, self.x_velocity))
        self.y_velocity = max(-1, min(1, self.y_velocity))

        # Boundary handling (bouncing with position correction)
        if self.x < 0:
            self.x = 0  # Ensure it stays within the left boundary
            self.x_velocity *= -1  # Reverse horizontal direction

        if self.x > self.screen_width:
            self.x = self.screen_width  # Ensure it stays within the right boundary
            self.x_velocity *= -1  # Reverse horizontal direction

        if self.y < 0:
            self.y = 0  # Ensure it stays within the top boundary
            self.y_velocity *= -1  # Reverse vertical direction

        if self.y > self.screen_height:
            self.y = self.screen_height  # Ensure it stays within the bottom boundary
            self.y_velocity *= -1  # Reverse vertical direction


    def get_position(self):
        return (self.x, self.y)

    def get_total_velocity(self):
        return self.x_velocity+self.y_velocity

rainbowSize=60
rainbow=generateRainbow(rainbowSize)
##screen_measurer## ---------------->                                                                                   33|                        41|                               53|                                    63|
dim=54
screen=[[0]*dim]*dim
mid=int(dim/2)
screenPrint=''
orb = Orb(x=mid, y=mid, screen_width=dim, screen_height=dim,speed=1.2)
i=1
while True:
    i+=1
    screenPrint=''
    for y,row in enumerate(screen):
        for x,pixel in enumerate(screen):
            color=rainbow[(int((math.dist((x,y),orb.get_position())**1.9 - abs(orb.get_total_velocity()))/16)-i )% rainbowSize]
            screenPrint+=f'\033[48;2;{int(color[0])};{int(color[1])};{int(color[2])}m  \033[0m'
        screenPrint+='\n'
    os.system('cls' if os.name == 'nt' else 'clear')
    orb.update_position()
    print(screenPrint)
    time.sleep(0.03)
