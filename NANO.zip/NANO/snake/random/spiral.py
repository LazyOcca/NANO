import os,math,time

def goto(xy:tuple[int,int]):
    x,y=xy
    print(f'\033[{y+1};{x+1}H',end='')

def drawAt(char:str,xy:tuple[int,int]):
    goto(xy)
    print(char,end='')
    goto((0,0))
    print('\0')

def drawPixelAt(rgb:tuple[int,int,int],xy:tuple[int,int],content:str='  '):
    x,y=xy
    x*=2
    if rgb is None:
        pixel=content
    else: 
        r,g,b=rgb
        pixel=f'\033[48;2;{r};{g};{b}m{str(content).rjust(2," ")}\033[0m'
    drawAt(pixel,(x,y))

import math



def generate_spinning_archimedean_spiral(a, b, num_points, omega=0.1, theta_0=0):
    points = []
    for i in range(num_points):
        t = i  # Using index as time variable
        theta = theta_0 + omega * t  # Update the angle over time
        r = a + b * theta  # Archimedean spiral radius
        x = r * math.cos(theta)
        y = r * math.sin(theta)
        points.append((x, y))
    return points

# Parameters for the spiral
a = 0
b = 0.5  # Controls spacing
num_points = 100  # Number of points
omega = 0.1  # Angular velocity (spin speed)
theta_0 = 0  # Initial angle

while 1:
    theta_0+=0.1
    spiral_points = generate_spinning_archimedean_spiral(a, b, num_points, omega, theta_0)
    print('\033[2J')
    for point in spiral_points:
        point = tuple([int(x) for x in point])
        point = (point[0]+15,point[1]+15)
        drawPixelAt((255,0,0),point)
    input()

