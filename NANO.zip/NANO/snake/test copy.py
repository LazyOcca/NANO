


lst = ["1","2","3","4","5"]



print(lst)
print(repr(lst)[1:-1].replace("'",'').replace('"',''))
# print(f'{*[lst]}')















