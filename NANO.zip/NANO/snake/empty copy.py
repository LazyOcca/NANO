
def bin2dec(n):return sum([2**c*i for c,i in enumerate(n[::-1])])

def dec2bin(n,ans=()):return dec2bin(n//2,ans)+(n%2,) if n>1 else ans+(n%2,)

# binum=dec2bin(1)
# print('binum:',binum)
# print('bin2dec:',bin2dec(binum))

def sqrt_heron(n,tolerantie=0.00000001,resultaat=0):

    resultaat = n
    while resultaat**2-n>tolerantie:
         print(resultaat)
         resultaat = (resultaat + (n/resultaat)) / 2

    return resultaat


def sqrt_heron(n,tolerantie=0.00000001,resultaat=None):
    return sqrt_heron(n,resultaat=n) if resultaat is None else sqrt_heron(n,resultaat=(resultaat+n/resultaat)/2) if resultaat**2-n>tolerantie else resultaat



num=0
print('number:',num)
print('sqrt:',sqrt_heron(num))
