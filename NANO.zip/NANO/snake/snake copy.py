import os,sys,tty,termios,threading,time,random,pickle

'''
=========
  TO DO
=========
=== AI ===
-preset route (stupid)
-random (just a lil dumb)
>fully random
>smart random
+smart (smart)
=== MULTIPLAYER ===
-fix update order
>no cell priority per tick (player1)
>no tail biting (player2)
-scoreboard
>also make draw (if they bump head) (maybe larger snake wins)
'''

class Snake():
    def __init__(self):
        self.x=0
        self.y=0
        self.xy=(self.x,self.y)
        self.direction='right'
        self.tail=(180,180,180)
        self.head=(255,255,255)
        self.decapitated=False
        self.length=4
        self.path=[self.xy]
        self.isFade=True
        self.keybinds={}
        self.keyBuffer=[]
        self.brain='human' #can be human or AI type (like 'smart' or 'random')
    
    def draw(self):
        if len(self.path)>0:

            if len(self.path)>self.length:
                drawFieldTile(self.path[0])
                del self.path[0]

            if self.isFade:
                snakeSize=len(self.path)
                for c,(s,p) in enumerate(zip(range(snakeSize-1),self.path)):
                    r,g,b=[int(round(self.tail[i]+(((self.head[i]-self.tail[i])/(snakeSize-1))*s),0)) for i in range(3)]
                    drawPixelAt((r,g,b),p)    
            else:
                drawPixelAt(self.tail,self.path[-2])

            if not self.decapitated:
                drawPixelAt(self.head,self.path[-1])

    def erase(self):
        for p in self.path:
            drawFieldTile(p)
    
    def updateDirection(self):
        tarDir=self.keybinds[self.keyBuffer.pop(0)] #targeted direction
        if not (tarDir==self.direction or tarDir==oppositeDirection[self.direction]):
            self.direction=tarDir
            
    def updateLocation(self):
        targetXY=translate(self.xy,directionTranslation[self.direction])
        if checkCollision(targetXY):
            gameOver(grave=targetXY)
        return targetXY

class Route(Snake):
    def __init__(self):
        super().__init__()
        self.head=(55,75,55)
        self.tail=(180,185,180)
        self.length=1000
        self.path=[]

    def line(axis,startXY,stop,fix,step):
        path=[]
        startX,startY=startXY
        if axis=='x':
            for x in range(startX,stop,step):
                path.append((x,fix))
            return path
        else:
            for y in range(startY,stop,step):
                path.append((fix,y))
            return path

    def shortest(startXY,goalXY,direction):
        startX,startY=startXY
        goalX,goalY=goalXY
        dx,dy=goalX-startX,goalY-startY
        stepX=posneg(dx)
        stepY=posneg(dy)
        path=[]
        if direction=='x':
            path+=Route.line('x',startXY,goalX,startY,stepX)
            path+=Route.line('y',startXY,goalY,goalX,stepY)
        else: #=='y'
            path+=Route.line('y',startXY,goalY,startX,stepY)
            path+=Route.line('x',startXY,goalX,goalY,stepX)

        path.append(goalXY)
        return path
    
    def shortUntilHit(snake,startXY,goalXY,direction):
        route=Route.shortest(startXY,goalXY,direction)
        for node,routeXY in enumerate(route[1:],1):
            collisionData=checkCollisionType(routeXY)
            if collisionData['type']=='snake':
                route=route[:node+1]
                return route,True
        return route,False

class Apple():
    def __init__(self):
        self.xy=(5,5)
        self.scenario=[]
    
    def spawn(self):
        if len(self.scenario)>0:
            self.xy=self.scenario.pop(0)
        else:
            mask=field[:]
            for snake in snakes:
                mask=list(set(mask)-set(snake.path))
            # mask=list(set(mask)-set(border))#only if i have 'obstacles'
            self.xy=random.choice(mask)
        # return self.xy
    
    def draw(self):
        drawPixelAt((255,0,0),self.xy)

class AI(Snake):
    def preset(snake):
        return 'up'

    def random(snake):
        safeDirections=[]
        possibleDirections=allDirections[:]
        possibleDirections.remove(oppositeDirection[snake.direction])
        


        closestDirections=[]
        lowestDistance=distance(snake.xy,apple.xy)-1
        for dir in possibleDirections:
            curXY=translate(snake.xy,directionTranslation[dir])
            curDis=distance(curXY,apple.xy)
            if curDis==lowestDistance:
                closestDirections.append(dir)
        
   
        staightBias=5
        possibleDirections+=[snake.direction]*staightBias

        hungerBias=10
        for dir in closestDirections:
            possibleDirections+=[dir]*hungerBias


        for dir in possibleDirections:
            targetXY=tuple((a+b for a,b in zip(snake.xy,directionTranslation[dir])))
            if not checkCollision(targetXY):
                safeDirections.append(dir)

        isPrintDebug=0
        if isPrintDebug:
            drawAt(f'up:   {"up"   in safeDirections}',(50,4))
            drawAt(f'down: {'down' in safeDirections}',(50,5))
            drawAt(f'left: {'left' in safeDirections}',(50,6))
            drawAt(f'right:{'right'in safeDirections}',(50,7))
            drawAt(f'\r{possibleDirections}|{safeDirections}                            ',(0,0))
        return random.choice(safeDirections) if safeDirections else snake.direction

    def smart(snake,appleXY):
        side=oppositeAxis[directionAxis[snake.direction]]
        route,didHit=Route.shortUntilHit(snake,snake.xy,appleXY,side)
        endRoute=[]
        safety=0
        while didHit and safety<50:
            eprint()
            eprint(didHit)
            safety+=1
            crashSite=route.pop()
            preImpact=route[-1]
            endRoute+=route
            eprint(f"{safety}: {route}")
            leftOfCrahs=left(preImpact,crashSite)
            rightOfCrash=right(preImpact,crashSite)
            eprint(snake.path)
        else:
            endRoute+=route 

        return endRoute

    ################
    def follow(snake,route):
        if len(route.path)>0:
            del route.path[0]
            for dir in allDirections:
                if route.path[0]==translate(snake.xy,directionTranslation[dir]):
                    return dir
        else: return snake.direction

def left(curXY,tarXY):
    relX,relY=relative(tarXY,curXY)
    if relX==0:
        leftX=relY
        leftY=relY
    elif relY==0:
        leftX=relX
        leftY=relX*-1
    return translate((leftX,leftY),curXY)

def right(curXY,tarXY):
    relX,relY=relative(tarXY,curXY)
    if relX==0:
        leftX=relY*-1
        leftY=relY
    elif relY==0:
        leftX=relX
        leftY=relX
    return translate((leftX,leftY),curXY)

def adjacent(curXY):
    curX,curY=curXY                                #up     right down  left
    return [(curX+tarX,curY+tarY) for tarX,tarY in [(0,-1),(1,0),(0,1),(-1,0)]]

def translate(xy,ab):
    (x,y),(a,b)=xy,ab
    return (x+a,y+b)

def relative(xy,ab):
    (x,y),(a,b)=xy,ab
    return (x-a,y-b)

def distance(xy,ab):
    (x,y),(a,b)=xy,ab
    return (abs(x-a)+abs(y-b))

def closestTo(checkList:list[tuple[int,int]],tarXY:tuple[int,int]):
    nodes={node:distance(node,tarXY) for node in checkList}
    closestDistance=min(nodes.values())
    return [node for node in nodes if nodes[node]==closestDistance]

def posneg(value):
    return -1 if value<0 else 1
    
filePath=os.path.dirname(os.path.abspath(__file__))

eprintpath = filePath+'/eprint/eprint.txt'
with open(eprintpath,"w") as e:pass
def eprint(txt:str='',end:str='\n'):
    with open(eprintpath,"a") as eprint:
        eprint.write(str(txt)+end)
    
highScoresPath=filePath+"/highScores/highScores.pkl"
def getHighScores():
    with open(highScoresPath, "rb") as file:
        highScores = pickle.load(file)
    return highScores

def getHighScore(highScores):
    Hscore=0
    for name in highScores:
        Cscore=highScores[name]['score']
        if Cscore>Hscore:
            Hscore=Cscore
            Hname=name
    return {'name':Hname,'score':Hscore}

def setHighScores(fieldDimension:tuple[int,int],snakeSpeed:int,name:str,score:int):
    highScores.setdefault(fieldDimension,{}).setdefault(snakeSpeed,{}).setdefault(name,{'score': score})
    if score>highScores[fieldDimension][snakeSpeed][name]['score']:
        highScores[fieldDimension][snakeSpeed][name] = {'score':score}
    with open(highScoresPath, "wb") as file:
        pickle.dump(highScores,file)

#########################################################################################
def get_key():
    global isExit
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
        print(ch)
        if ch == "\x1b": #if arrow or some
            ch = sys.stdin.read(2)
            match ch:
                case '[A': return "Up arrow key"
                case '[B': return "Down arrow key"
                case '[C': return "Right arrow key"
                case '[D': return "Left arrow key"
                case '[1': sys.stdout.flush()
                case _: 
                    sys.stdout.flush()
                    isExit=True
        else:
            return ch.upper()
            
    finally:
        ...
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

# while 1: print(get_key())

def keepUpdatingKey():
    try:

        while True:
            key = get_key()
            for snake in snakes:
                if len(snake.keyBuffer)<=1:
                    if key in snake.keybinds:
                        snake.keyBuffer.append(key)  
    except:pass

def goto(xy:tuple[int,int]):
    x,y=xy
    print(f'\033[{y+1};{x+1}H',end='')

def drawAt(char:str,xy:tuple[int,int]):
    goto(xy)
    print(char,end='')
    goto((0,0))
    print('\0')

def drawPixelAt(rgb:tuple[int,int,int],xy:tuple[int,int],content:str='  '):
    x,y=xy
    x*=2
    if rgb is None:
        pixel=content
    else: 
        r,g,b=rgb
        pixel=f'\033[48;2;{r};{g};{b}m{str(content).rjust(2," ")}\033[0m'
    drawAt(pixel,(x,y))

def generateField(fieldXY:tuple[int,int],offsetXY:tuple[int,int]=(1,1)):
    offsetX,offsetY=offsetXY
    field=[]
    for fieldX in range(fieldXY[0]):
        for fieldY in range(fieldXY[1]):
            field.append((fieldX+offsetX+1,fieldY+offsetY+1))
    return field

def drawField(field):
    for xy in field:
        drawFieldTile(xy)

def drawFieldTile(xy):
    x,y=xy
    if (x+y)%2:
        tileColor=(20,20,20)
    else: tileColor=(30,30,30)
    drawPixelAt(tileColor,(x,y))

def generateBorder(borderXY:tuple[int,int],offsetXY:tuple[int,int]=(1,1)):
    offsetX,offsetY=offsetXY
    borderX=[i for i in range(offsetX,borderXY[0]+offsetX)]
    borderY=[i for i in range(offsetY,borderXY[1]+offsetY)]
    border=[]

    for x in borderX:
        for y in [borderY[0],borderY[-1]]:
            border.append((x,y))

    for y in borderY[1:-1]:
        for x in [borderX[0],borderX[-1]]:
            border.append((x,y))
    return border

def drawBorder(rgb:tuple[int,int,int],border:list[tuple[int,int]]):
    for xy in border:
        drawPixelAt(rgb,xy)

def getVertebra(xy):
    for snake in snakes:
        for n,p in enumerate(snake.path[1:],1):
            if p==xy: return n

def checkCollision(xy):
    if xy in border:
        return True
    for snake in snakes:
        if xy in snake.path[1::]:
            return True
    return False

def checkCollisionType(xy):
    data={'type':'none','info':None}

    if xy in border:
        data['type']='border'
        return data
    
    for p in snake1.path[1:]:
        if p==xy:
            data['type']='snake'
            data['info']=getVertebra(xy)
            return data
        
    return data

def blink(grave):
    while isBlink:
        drawPixelAt((255,255,0),grave)
        time.sleep(0.3)
        if isBlink!=True: break
        drawPixelAt((255,42,42),grave)
        time.sleep(0.3)

def restart(**preGive):
    if preGive==None:
        os.execv(sys.executable, ['python'] + sys.argv)
    else:
        os.execv(sys.executable, ['python'] + sys.argv + [f"{preGive}"])

def gameOver(grave:tuple[:int,:int]=None,hasWon:bool=False):
    if hasWon: winPrint='You won!!!'
    else: 
        winPrint='Game over.'
        global isBlink
        isBlink=1
        blinky = threading.Thread(target=blink,args=(grave,))
        blinky.start()
    drawAt(f'{winPrint} [press any arrow key to retry]',(offsetX*2,offsetY-2))
        
    time.sleep(0.3)
    while snake1.keyBuffer: snake1.keyBuffer.pop()
    while not snake1.keyBuffer: pass
    snake1.keyBuffer.pop()

    isBlink=0
    time.sleep(0.3)
    print('\033[2J')
    if not isMultiPlayer and not isCheat:
        setHighScores(fieldDimensions,framRate,name,snake1.length)
    
    restart(isMultiPlayer=isMultiPlayer,name=name,isAI=isAI,isCheat=isCheat,typeAI=typeAI)



#inputs
isAI=False
isCheat=False
print('\033[2J')
if len(sys.argv) > 1: #if restared
    preGiven=eval(sys.argv[1])
    isMultiPlayer=preGiven['isMultiPlayer']
    name=preGiven['name']
    isAI=preGiven['isAI']
    typeAI=preGiven['typeAI']
    isCheat=preGiven['isCheat']
    #=preGiven['']
elif 1: #lazy input
    isMultiPlayer=1
    name='OSCAR'
    isAI=0
    isCheat=1
    typeAI='random'
else: #actual input
    yesList = ['true','1','yes','yep','o','y','ye','yea','yeah','ya',*['ya'+'s'*s for s in range(10)]]
    isMultiPlayer = input('Enable multiplayer?\n') in yesList
    print('\033[2J')
    if isMultiPlayer:
        isAI = input("Want to play against AI?\n") in yesList
    else:
        isAI = input("Want AI to play?\n") in yesList
        if not isAI:
            print('\033[2J')
            name=input('name?\n').upper()
    print('\033[2J')

    if isAI: 
        name='AI'
        isCheat=True
        typeAI='preset' #preset,random,smart
if isAI: isCheat=True

fieldWidth = 20
fieldHeight = 10
fieldDimensions = (fieldWidth,fieldHeight)
borderWidth = fieldWidth+2
borderHeight = fieldHeight+2
borderColor = (0,0,255)
offsetX = 3
offsetY = 3
field = generateField((fieldWidth,fieldHeight),(offsetX,offsetY))
border = generateBorder((borderWidth,borderHeight),(offsetX,offsetY))
# border+=[(random.randint(offsetX,fieldWidth+offsetX),random.randint(offsetY,fieldHeight+offsetY)) for i in range(20)]
drawField(field)
drawBorder(borderColor,border)


allDirections=['up','down','left','right']
oppositeDirection={'up':'down','down':'up','left':'right','right':'left'}
oppositeAxis={'x':'y','y':'x'}
directionAxis={'up':'y','down':'y','left':'x','right':'x'}
directionTranslation={'up':(0,-1),'down':(0,1),'left':(-1,0),'right':(1,0)}
arrows={"Up arrow key":'up',"Left arrow key":'left',"Down arrow key":'down',"Right arrow key":'right'} #the keys are the keys lol
wasd={"W":'up',"A":'left',"S":'down',"D":'right'}


route1=Route()

snake1 = Snake()
snake1.x = int(min(borderWidth/3+offsetX,borderHeight/2+offsetY))
snake1.y = int(borderHeight/2+offsetY)
snake1.xy = (snake1.x,snake1.y)
snake1.direction = 'right'
snake1.tail = (31,127,31)
snake1.head = (0,255,31)
snake1.length = 4
snake1.path = []
snake1.isFade = True
snake1.keybinds=arrows
snake1.brain='human'
snakes=[snake1]

if isMultiPlayer:
    snake1.x = offsetX+2
    snake1.y = offsetY+2
    snake1.xy = (snake1.x,snake1.y)
    snake2 = Snake()
    snake2.x = fieldWidth+offsetX-1
    snake2.y = fieldHeight+offsetY-1
    snake2.xy = (snake2.x,snake2.y)
    snake2.direction = 'left'
    snake2.tail = (232,109,2)
    snake2.head = (252,180,30)
    snake2.length = 4
    snake2.path = []
    snake2.isFade = True
    snake2.keybinds=wasd
    # snake2.keybinds=arrows
    if isAI: snake2.brain=typeAI
    else: snake2.brain='human'
    snakes.append(snake2)
else:#if solo
    eprint("solo")
    snake1.keybinds.update(wasd)
    if isAI: snake1.brain=typeAI

# line=[(10,9),(12,9),(13,9),(14,9),(15,9),(16,9),(17,9),(18,9),(19,9),(20,9)]
# scenario= [*line,(18,12),(18,6)]
# scenario=[(11,10)]
apples=[]
appleCount=1
for i in range(appleCount):
    apple=Apple()
    apple.spawn()
    apple.draw()
    apples.append(apple)


threadKey = threading.Thread(target=keepUpdatingKey)
threadKey.start()
key = 'Right arrow key'

frame = 0
framRate = 7
hasWon = False
isExit = False

if not isMultiPlayer:
    highScores = getHighScores()
    highScore={'name':'OSCAR','score':102}
    try:
        highScore = getHighScore(highScores[fieldDimensions][framRate])
    except: pass

time.sleep(0)

#####################################################
if isAI and typeAI=='smart':
    route1.path=Route.shortest(snake1.xy,apple.xy,oppositeAxis[directionAxis[snake1.direction]])
    route1.draw()


while True:
    frame+=1
    startTime=time.time()
    ##############################
    for snake in snakes:
        match snake.brain:
            case 'human' : 
                if snake.keyBuffer:
                    snake.updateDirection()
            case 'random': snake.direction=AI.random(snake)
            case 'preset': snake.direction=AI.preset(snake)
            case 'smart' :
                snake.direction=AI.follow(snake,route1)


        snake.xy = snake.updateLocation()
        snake.path.append(snake.xy)
         

        if hasWon:
            gameOver(hasWon=True)
        
        for apple in apples:
            if apple.xy==snake.xy:
                snake.length+=1
                hasWon=snake.length==fieldWidth*fieldHeight
                if not hasWon: 
                    apple.spawn()
                    apple.draw()
                    if isAI and typeAI=='smart':
                        route1.path=AI.smart(snake,apple.xy)

        
        if isAI: 
            snake.draw()
        for apple in apples: apple.draw()
        snake.draw()
    ##############################

    drawAt(f'score: {snake1.length}'+(f' | high score: {highScore["score"]} (by {highScore["name"]})' if not isMultiPlayer else ''),(offsetX*2,offsetY-1))

    if isExit:
        exit()
    while not time.time()>startTime+1/framRate:pass
    