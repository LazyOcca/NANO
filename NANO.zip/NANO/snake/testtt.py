def ceil(val):
    

print()