import random, time


while True:
    gameMode = input("What you wanna do?\n[1] bin to dec   [2] dec to bin\n: ")
    if gameMode in ['1','2']:
        gameMode=int(gameMode)
        break
    print("\ntry again buddy")

while gameMode==1:
    print('\n\n')
    nummy = random.randint(0,255)
    binny = bin(nummy)[2:]
    deccy = int(input(f"bin: {str(binny).zfill(8)}\ndec: "))
    if nummy==deccy:
        print("Correct!")
    else:
        print(f"WRONG, it was {nummy}")

while gameMode==2:
    print('\n\n')
    deccy = str(int(random.randint(0,255)))
    binny = input(f"dec: {deccy}\nbin: ")
    if deccy==binny:
        print("Correct!")
    else:
        print(f"WRONG, it was {binny}")




