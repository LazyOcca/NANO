import os,random,sys,termios,tty,math
'''
todo

make ai go around abstacles
'''

def restart(**preGive):
    if preGive is None:
        os.execv(sys.executable, ['python'] + sys.argv)
    else:
        os.execv(sys.executable, ['python'] + sys.argv + [f"{preGive}"])

def get_key():
    global isExit
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
        if ch == "\x1b": #if arrow or some
            ch = sys.stdin.read(2)
            match ch:
                case '[A': return "Up arrow key"
                case '[B': return "Down arrow key"
                case '[C': return "Right arrow key"
                case '[D': return "Left arrow key"
                case '[1': sys.stdout.flush()
                case _: 
                    sys.stdout.flush()
                    exit()
        else:
            return ch.upper()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

class Snake():
    def __init__(self):
        self.x=0
        self.y=0
        self.xy=(self.x,self.y)
        self.direction='right'
        self.tail=(31,127,31)
        self.head=(0,255,31)
        self.length=50
        self.path=[self.xy]
        self.isFade=True

class Route(Snake):
    def __init__(self):
        super().__init__()
        self.head=(90,95,90)
        self.tail=(222,222,222)
        self.length=50
        self.path=[]

filePath=os.path.dirname(os.path.abspath(__file__))

eprintpath = filePath+'/eprint/eprint.txt'
def clear_eprint():
    with open(eprintpath,"w") as e:pass

clear_eprint()
def eprint(txt:str='',end:str='\n'):
    with open(eprintpath,"a") as eprint:
        eprint.write(str(txt)+end)

def goto(xy:tuple[int,int]):
    x,y=xy
    print(f'\033[{y+1};{x+1}H',end='')

def drawAt(char:str,xy:tuple[int,int]):
    goto(xy)
    print(char,end='')
    goto((0,0))
    print('\0')

def drawPixelAt(rgb:tuple[int,int,int],xy:tuple[int,int],content:str='  '):
    x,y=xy
    x*=2
    if rgb is None:
        pixel=content
    else: 
        pixel=f'\033[48;2;{rgb[0]};{rgb[1]};{rgb[2]}m{str(content).rjust(2," ")}\033[0m'
    drawAt(pixel,(x,y))

def generateField(fieldXY:tuple[int,int],offsetXY:tuple[int,int]=(0,0)):
    offsetX,offsetY=offsetXY
    field=[]
    for fieldX in range(fieldXY[0]):
        for fieldY in range(fieldXY[1]):
            field.append((fieldX+offsetX,fieldY+offsetY))
    return field

def drawField(field):
    for xy in field:
        drawFieldTile(xy)

def drawFieldTile(xy):
    x,y=xy
    content=' '
    if (x+y)%2:
        tint=20
    else: tint=30
    if not (x and y):
        tint*=3
        if x==0: content=y
        elif y==0: content=x
    tileColor=(tint,tint,tint)
    drawPixelAt(tileColor,(x,y),content)

def drawSnake(snake,drawHead=True):
    if len(snake.path)>1:
        if snake.isFade:
            snakeSize=len(snake.path)
            for c,(s,p) in enumerate(zip(range(snakeSize),snake.path)):
                r,g,b=[int(round(snake.tail[i]+(((snake.head[i]-snake.tail[i])/(snakeSize-1))*s),0)) for i in range(3)]
                drawPixelAt((r,g,b),p,c)    
        else:
            drawPixelAt(snake.tail,snake.path[-2])
        # if len(snake.path)>snake.length:
        #     drawFieldTile(snake.path[0])
        #     del snake.path[0]
        # if drawHead:
        #     drawPixelAt(snake.head,snake.path[-1])

def drawList(lst,rgb,content='  '):
    for xy in lst:
        drawPixelAt(rgb,xy,content)

def drawApple(appleXY):
    drawPixelAt((255,0,0),appleXY,"\u0358 ")

def posneg(value):
    return -1 if value<0 else 1

def adjacent(curXY):
    curX,curY=curXY                                #up     right down  left
    return [(curX+tarX,curY+tarY) for tarX,tarY in [(0,-1),(1,0),(0,1),(-1,0)]]

def relative(xy,ab):
    (x,y),(a,b)=xy,ab
    return (x-a,y-b)

def translate(xy,ab):
    (x,y),(a,b)=xy,ab
    return (x+a,y+b)

def distance(xy,ab):
    (x,y),(a,b)=xy,ab
    return (abs(x-a)+abs(y-b))

def isInBounds(xy):
    curX,curY=xy
    limX,limY=fielDim
    return limX>curX>0 and limY>curY>0

def isOutOfBounds(xy):
    return not isInBounds(xy)

class Path():
    def line(axis,startXY,stop,fix,step):
        path=[]
        startX,startY=startXY
        if axis=='x':
            for x in range(startX,stop,step):
                path.append((x,fix))
            return path
        else:
            for y in range(startY,stop,step):
                path.append((fix,y))
            return path

    def shortest(startXY,goalXY,direction):
        startX,startY=startXY
        goalX,goalY=goalXY
        dx,dy=goalX-startX,goalY-startY
        stepX=posneg(dx)
        stepY=posneg(dy)
        path=[]
        if direction=='x':
            path+=Path.line('x',startXY,goalX,startY,stepX)
            path+=Path.line('y',startXY,goalY,goalX,stepY)
        else: #=='y'
            path+=Path.line('y',startXY,goalY,startX,stepY)
            path+=Path.line('x',startXY,goalX,goalY,stepX)

        path.append(goalXY)
        return path

def ft(*tup):#frozen tuple = a tuple in a frozen set
    return frozenset({tup})

def isCollision(xy): return xy in obstacles

def shiftList(lst:list,amount:int=1):
    amount %= len(lst)
    return lst[amount:]+lst[:amount]

def generateRainbow(size):
    rainbow=[]
    rgb=(255,0,0)
    fakeSize=math.ceil(size/6)
    grade=fakeSize
    scale=(255)/grade
    for s in [(0 ,1 ,0 ),(-1,0 ,0 ),(0 ,0 ,1 ),(0 ,-1,0 ),(1 ,0 ,0 ),(0 ,0 ,-1)]:
        s=(s[0]*scale,s[1]*scale,s[2]*scale)
        for g in range(grade):
            rainbow.append((int(rgb[0]),int(rgb[1]),int(rgb[2])))
            rgb=(rgb[0]+s[0],rgb[1]+s[1],rgb[2]+s[2])
    return rainbow[:size]

class AI():
    def findTarget(tarXY,curXY,step=0,route=[],breadCrumbs={}):
        # eprint(f'{1}')
        isFinished=curXY==tarXY
        step+=1
        route=route[:]
        crumb=breadCrumbs.setdefault(ft(curXY),'free')
        isCollided=isCollision(curXY)
        # eprint(f'\n{step}|{crumb}:')
        if isFinished or isCollided: 
            route.append(curXY)
            return route,isCollided,isFinished
        if crumb!='free' and step<crumb:
                if curXY in route:
                    route.remove(curXY)
                crumb='free'
        if step>16:
            # eprint("step too big")
            pass
        elif crumb=='free':
            route.append(curXY)
            breadCrumbs[ft(curXY)]=step
            # eprint(f'{route}\n{breadCrumbs}')

            nodes={}
            for nodeXY in adjacent(curXY):
                nodes[nodeXY]=distance(nodeXY,tarXY)

            nodes={i:isCollision(i) for i in nodes if nodes[i]==min(nodes.values())}
            eprint(nodes)
            # if not (True in nodes.values()):
            #     return route[:-1],True,isFinished
            
            for nodeXY in nodes:
                eprint(f"{isFinished,route}")
                route,nodeCollided,isFinished=AI.findTarget(tarXY,nodeXY,step,route,breadCrumbs)

                if nodeCollided:
                    # return route,nodeCollided,isFinished
                    continue

                if isFinished: 
                    # route.append(curXY)
                    return route,nodeCollided,isFinished
                
        elif step>crumb:
            # eprint("found bigger crumb")
            pass
        
        return route,isCollided,isFinished
    def findTarget(tarXY,curXY,step=0,route=[],breadCrumbs={}):
        ...

def getArea(xy):
    breadCrumbs=[]
    beginColor=canvas[xy]
    forObstacle=xy in obstacles
    area=scanArea(xy,beginColor,breadCrumbs,forObstacle)
    return area

def scanArea(xy,beginColor,breadCrumbs,forObstacle,step=0):
    step+=1
    if step>1000 or isOutOfBounds(xy) or forObstacle!=(xy in obstacles):
        return breadCrumbs
    for node in adjacent(xy):#
        if (isInBounds(node)) and (not node in breadCrumbs) and (forObstacle==(node in obstacles)) and (beginColor==canvas[node]) :
            breadCrumbs.append(node)
            breadCrumbs=scanArea(node,beginColor,breadCrumbs,forObstacle,step)
    return breadCrumbs

class Brush():
    def __init__(self):
        self.color=(255,0,0)
        self.colorIndex=0
        self.palette=generateRainbow(18)
    
    def shiftColor(self,shift):
        self.colorIndex=(self.colorIndex+shift)%len(self.palette)
        self.color=self.palette[self.colorIndex]

class Mark(Brush):
    def __init__(self):
        super().__init__()
        self.face='••'
        self.skin=(250,200,255)
        self.xy=(5,6)

    def draw(self,color=None):
        if color is None: color=self.skin
        drawPixelAt(color,self.xy,self.face)

presets={'penis':[(6, 8), (5, 9), (5, 10), (5, 11), (6, 12), (7, 12), (8, 12), (9, 12), (9, 11), (9, 10), (9, 9), (9, 8), (8, 8), (7, 8), (7, 7), (7, 6), (7, 4), (7, 5), (7, 3), (7, 2), (8, 1), (9, 1), (10, 1), (11, 2), (11, 3), (11, 4), (11, 5), (11, 6), (11, 7), (11, 8), (10, 8), (10, 12), (11, 12), (12, 12), (13, 11), (13, 10), (13, 9), (12, 8)],
         'nothing':[],'void':[],'n':[],'':[],
         'ripples':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (2, 14), (2, 12), (3, 12), (2, 10), (3, 10), (4, 10), (2, 3), (2, 5), (3, 5), (2, 7), (3, 7), (4, 7), (5, 9), (5, 8), (3, 2), (4, 4), (5, 3), (5, 2), (4, 13), (5, 14), (5, 15), (3, 15), (7, 15), (7, 14), (7, 13), (8, 12), (9, 12), (10, 13), (10, 14), (10, 15), (14, 15), (15, 14), (12, 15), (12, 14), (13, 13), (14, 12), (15, 12), (15, 10), (14, 10), (13, 10), (12, 9), (12, 8), (13, 7), (14, 7), (15, 7), (15, 5), (14, 5), (13, 4), (12, 3), (12, 2), (14, 2), (15, 3), (10, 2), (10, 3), (10, 4), (9, 5), (8, 5), (7, 4), (7, 3), (7, 2), (6, 6), (7, 7), (7, 8), (7, 9), (7, 10), (6, 11), (8, 10), (9, 10), (10, 10), (11, 11), (10, 9), (10, 8), (11, 6), (10, 7), (9, 7), (8, 7)],
         'border':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1)],
         'star':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (8, 2), (9, 2), (8, 3), (8, 4), (2, 8), (3, 8), (4, 8), (5, 7), (6, 7), (7, 5), (7, 6), (9, 3), (9, 4), (10, 5), (10, 6), (11, 7), (12, 7), (13, 8), (14, 8), (15, 8), (15, 9), (14, 9), (13, 9), (12, 10), (11, 10), (10, 11), (10, 12), (9, 13), (9, 14), (9, 15), (8, 15), (8, 14), (8, 13), (7, 12), (7, 11), (6, 10), (5, 10), (4, 9), (2, 9), (3, 9), (1, 9)],
         'target':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (3, 3), (4, 3), (5, 3), (6, 3), (7, 3), (8, 3), (9, 3), (10, 3), (11, 3), (12, 3), (13, 3), (14, 3), (14, 4), (14, 5), (14, 6), (14, 7), (14, 8), (14, 9), (14, 10), (14, 11), (14, 12), (14, 13), (14, 14), (13, 14), (12, 14), (11, 14), (10, 14), (9, 14), (8, 14), (7, 14), (6, 14), (5, 14), (4, 14), (3, 14), (3, 13), (3, 12), (3, 11), (3, 10), (3, 9), (3, 8), (3, 7), (3, 6), (3, 5), (3, 4), (5, 5), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5), (11, 5), (12, 5), (12, 6), (12, 7), (12, 8), (12, 9), (12, 10), (12, 11), (11, 12), (12, 12), (10, 12), (9, 12), (8, 12), (7, 12), (5, 12), (6, 12), (5, 11), (5, 10), (5, 9), (5, 8), (5, 7), (5, 6), (7, 7), (8, 7), (9, 7), (10, 7), (10, 8), (10, 9), (10, 10), (9, 10), (8, 10), (7, 10), (7, 9), (7, 8)],
         'waffle':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (4, 2), (4, 3), (4, 4), (3, 4), (2, 4), (5, 4), (6, 4), (7, 4), (7, 3), (7, 2), (8, 4), (9, 4), (10, 4), (10, 3), (10, 2), (11, 4), (12, 4), (13, 3), (13, 4), (13, 2), (14, 4), (15, 4), (13, 5), (13, 6), (13, 7), (13, 8), (13, 9), (13, 10), (13, 11), (13, 12), (13, 13), (13, 14), (13, 15), (10, 15), (10, 14), (10, 13), (10, 12), (10, 11), (10, 10), (10, 9), (10, 8), (10, 7), (10, 6), (10, 5), (7, 5), (7, 6), (7, 8), (7, 9), (7, 10), (7, 11), (7, 12), (7, 13), (7, 14), (7, 15), (4, 15), (4, 14), (4, 13), (4, 12), (4, 11), (4, 10), (4, 9), (4, 8), (4, 6), (4, 5), (2, 7), (3, 7), (5, 7), (6, 7), (4, 7), (7, 7), (8, 7), (9, 7), (11, 7), (12, 7), (14, 7), (15, 7), (15, 10), (14, 10), (12, 10), (11, 10), (9, 10), (8, 10), (6, 10), (5, 10), (3, 10), (2, 10), (2, 13), (3, 13), (5, 13), (6, 13), (8, 13), (9, 13), (11, 13), (12, 13), (14, 13), (15, 13)],
         'TicTacToe':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (6, 2), (11, 2), (11, 3), (11, 4), (11, 5), (11, 6), (11, 7), (11, 8), (11, 10), (11, 12), (11, 13), (11, 14), (11, 15), (11, 11), (11, 9), (6, 3), (6, 4), (6, 5), (6, 6), (6, 7), (6, 8), (6, 9), (6, 10), (6, 11), (6, 12), (6, 13), (6, 14), (6, 15), (4, 6), (5, 6), (3, 6), (2, 6), (2, 11), (4, 11), (3, 11), (5, 11), (7, 11), (9, 11), (8, 11), (10, 11), (12, 11), (13, 11), (14, 11), (15, 11), (15, 6), (14, 6), (13, 6), (12, 6), (10, 6), (9, 6), (8, 6), (7, 6)],
         'checkers':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (2, 3), (3, 2), (2, 5), (3, 4), (4, 3), (5, 2), (7, 2), (9, 2), (11, 2), (13, 2), (15, 2), (14, 3), (12, 3), (10, 3), (8, 3), (6, 3), (5, 4), (7, 4), (9, 4), (11, 4), (13, 4), (15, 4), (14, 5), (12, 5), (10, 5), (8, 5), (6, 5), (4, 5), (3, 6), (5, 6), (7, 6), (9, 6), (11, 6), (13, 6), (15, 6), (14, 7), (12, 7), (10, 7), (8, 7), (6, 7), (4, 7), (2, 7), (3, 8), (5, 8), (7, 8), (9, 8), (11, 8), (13, 8), (15, 8), (14, 9), (12, 9), (10, 9), (8, 9), (6, 9), (4, 9), (2, 9), (3, 10), (5, 10), (7, 10), (9, 10), (11, 10), (13, 10), (15, 10), (14, 11), (12, 11), (10, 11), (8, 11), (6, 11), (4, 11), (2, 11), (3, 12), (5, 12), (7, 12), (9, 12), (11, 12), (13, 12), (15, 12), (14, 13), (12, 13), (10, 13), (8, 13), (6, 13), (4, 13), (2, 13), (3, 14), (5, 14), (7, 14), (9, 14), (11, 14), (13, 14), (15, 14), (14, 15), (12, 15), (10, 15), (8, 15), (6, 15), (4, 15), (2, 15)],
         'filled':[(1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1), (8, 1), (9, 1), (10, 1), (11, 1), (12, 1), (13, 1), (14, 1), (15, 1), (16, 1), (16, 2), (15, 2), (14, 2), (13, 2), (12, 2), (11, 2), (10, 2), (9, 2), (8, 2), (7, 2), (6, 2), (5, 2), (4, 2), (3, 2), (2, 2), (1, 2), (1, 3), (2, 3), (3, 3), (4, 3), (5, 3), (6, 3), (7, 3), (8, 3), (9, 3), (10, 3), (11, 3), (12, 3), (13, 3), (14, 3), (15, 3), (16, 3), (16, 4), (15, 4), (14, 4), (13, 4), (12, 4), (11, 4), (10, 4), (9, 4), (8, 4), (7, 4), (6, 4), (5, 4), (4, 4), (3, 4), (2, 4), (1, 4), (1, 5), (2, 5), (3, 5), (4, 5), (5, 5), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5), (11, 5), (12, 5), (13, 5), (14, 5), (15, 5), (16, 5), (16, 6), (15, 6), (14, 6), (13, 6), (12, 6), (11, 6), (10, 6), (9, 6), (8, 6), (7, 6), (6, 6), (5, 6), (4, 6), (3, 6), (2, 6), (1, 6), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (8, 7), (9, 7), (10, 7), (11, 7), (12, 7), (13, 7), (14, 7), (15, 7), (16, 7), (16, 8), (15, 8), (14, 8), (13, 8), (12, 8), (11, 8), (10, 8), (9, 8), (8, 8), (7, 8), (6, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (1, 9), (2, 9), (3, 9), (4, 9), (5, 9), (6, 9), (7, 9), (8, 9), (9, 9), (10, 9), (11, 9), (12, 9), (13, 9), (14, 9), (15, 9), (16, 9), (16, 10), (15, 10), (14, 10), (13, 10), (12, 10), (11, 10), (10, 10), (9, 10), (8, 10), (7, 10), (6, 10), (5, 10), (4, 10), (3, 10), (2, 10), (1, 10), (1, 11), (2, 11), (3, 11), (4, 11), (5, 11), (6, 11), (7, 11), (8, 11), (9, 11), (10, 11), (11, 11), (12, 11), (13, 11), (14, 11), (15, 11), (16, 11), (16, 12), (15, 12), (14, 12), (13, 12), (12, 12), (11, 12), (10, 12), (9, 12), (8, 12), (7, 12), (6, 12), (5, 12), (4, 12), (3, 12), (2, 12), (1, 12), (1, 13), (2, 13), (3, 13), (4, 13), (5, 13), (6, 13), (7, 13), (8, 13), (9, 13), (10, 13), (11, 13), (12, 13), (13, 13), (14, 13), (15, 13), (16, 13), (16, 14), (15, 14), (14, 14), (13, 14), (12, 14), (11, 14), (10, 14), (9, 14), (8, 14), (7, 14), (6, 14), (5, 14), (4, 14), (3, 14), (2, 14), (1, 14), (1, 15), (2, 15), (3, 15), (4, 15), (5, 15), (6, 15), (7, 15), (8, 15), (9, 15), (10, 15), (11, 15), (12, 15), (13, 15), (14, 15), (15, 15), (16, 15), (16, 16), (15, 16), (14, 16), (13, 16), (12, 16), (11, 16), (10, 16), (9, 16), (8, 16), (7, 16), (6, 16), (5, 16), (4, 16), (3, 16), (2, 16), (1, 16)],
         'aLastHope':[(1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1), (8, 1), (9, 1), (10, 1), (11, 1), (12, 1), (13, 1), (14, 1), (15, 1), (16, 1), (16, 2), (15, 2), (14, 2), (13, 2), (12, 2), (11, 2), (10, 2), (9, 2), (8, 2), (7, 2), (6, 2), (5, 2), (4, 2), (3, 2), (2, 2), (1, 2), (1, 3), (2, 3), (3, 3), (4, 3), (5, 3), (6, 3), (7, 3), (8, 3), (9, 3), (10, 3), (11, 3), (12, 3), (13, 3), (14, 3), (15, 3), (16, 3), (16, 4), (15, 4), (14, 4), (13, 4), (12, 4), (11, 4), (10, 4), (9, 4), (8, 4), (7, 4), (6, 4), (5, 4), (4, 4), (3, 4), (2, 4), (1, 4), (1, 5), (2, 5), (3, 5), (4, 5), (5, 5), (6, 5), (7, 5), (8, 5), (9, 5), (10, 5), (11, 5), (12, 5), (13, 5), (14, 5), (15, 5), (16, 5), (16, 6), (15, 6), (14, 6), (13, 6), (12, 6), (11, 6), (10, 6), (9, 6), (8, 6), (7, 6), (6, 6), (5, 6), (4, 6), (3, 6), (2, 6), (1, 6), (1, 7), (2, 7), (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (8, 7), (9, 7), (10, 7), (11, 7), (12, 7), (13, 7), (14, 7), (15, 7), (16, 7), (16, 8), (15, 8), (14, 8), (13, 8), (12, 8), (11, 8), (10, 8), (9, 8), (7, 8), (6, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (1, 9), (2, 9), (3, 9), (4, 9), (5, 9), (6, 9), (7, 9), (8, 9), (9, 9), (10, 9), (11, 9), (12, 9), (13, 9), (14, 9), (15, 9), (16, 9), (16, 10), (15, 10), (14, 10), (13, 10), (12, 10), (11, 10), (10, 10), (9, 10), (8, 10), (7, 10), (6, 10), (5, 10), (4, 10), (3, 10), (2, 10), (1, 10), (1, 11), (2, 11), (3, 11), (4, 11), (5, 11), (6, 11), (7, 11), (8, 11), (9, 11), (10, 11), (11, 11), (12, 11), (13, 11), (14, 11), (15, 11), (16, 11), (16, 12), (15, 12), (14, 12), (13, 12), (12, 12), (11, 12), (10, 12), (9, 12), (8, 12), (7, 12), (6, 12), (5, 12), (4, 12), (3, 12), (2, 12), (1, 12), (1, 13), (2, 13), (3, 13), (4, 13), (5, 13), (6, 13), (7, 13), (8, 13), (9, 13), (10, 13), (11, 13), (12, 13), (13, 13), (14, 13), (15, 13), (16, 13), (16, 14), (15, 14), (14, 14), (13, 14), (12, 14), (11, 14), (10, 14), (9, 14), (8, 14), (7, 14), (6, 14), (5, 14), (4, 14), (3, 14), (2, 14), (1, 14), (1, 15), (2, 15), (3, 15), (4, 15), (5, 15), (6, 15), (7, 15), (8, 15), (9, 15), (10, 15), (11, 15), (12, 15), (13, 15), (14, 15), (15, 15), (16, 15), (16, 16), (15, 16), (14, 16), (13, 16), (12, 16), (11, 16), (10, 16), (9, 16), (8, 16), (7, 16), (6, 16), (5, 16), (4, 16), (3, 16), (2, 16), (1, 16)],
         'diamond':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (2, 3), (3, 2), (2, 6), (3, 5), (4, 4), (5, 3), (6, 2), (3, 8), (4, 7), (5, 6), (6, 5), (7, 4), (8, 3), (14, 2), (15, 3), (15, 6), (14, 5), (13, 4), (12, 3), (11, 2), (9, 3), (10, 4), (11, 5), (12, 6), (13, 7), (14, 8), (14, 9), (13, 10), (12, 11), (11, 12), (10, 13), (9, 14), (8, 14), (7, 13), (6, 12), (5, 11), (4, 10), (3, 9), (6, 9), (6, 8), (7, 7), (8, 6), (9, 6), (10, 7), (11, 8), (11, 9), (10, 10), (9, 11), (8, 11), (7, 10), (2, 11), (3, 12), (4, 13), (5, 14), (6, 15), (3, 15), (2, 14), (11, 15), (12, 14), (13, 13), (14, 12), (15, 11), (15, 14), (14, 15)],
         'snake':[(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (2, 16), (3, 16), (4, 16), (5, 16), (6, 16), (7, 16), (8, 16), (9, 16), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16), (16, 15), (16, 14), (16, 13), (16, 12), (16, 11), (16, 10), (16, 9), (16, 8), (16, 7), (16, 6), (16, 5), (16, 4), (16, 3), (16, 2), (16, 1), (15, 1), (14, 1), (13, 1), (12, 1), (11, 1), (10, 1), (9, 1), (8, 1), (7, 1), (6, 1), (5, 1), (4, 1), (3, 1), (2, 1), (7, 3), (6, 3), (5, 3), (4, 3), (3, 3), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (3, 7), (3, 8), (4, 8), (5, 8), (6, 8), (7, 8), (8, 8), (9, 8), (10, 8), (11, 8), (11, 9), (11, 10), (10, 10), (9, 10), (8, 10), (7, 10), (7, 11), (7, 12), (7, 13), (8, 13), (9, 13), (10, 13), (10, 12), (11, 12), (12, 12), (13, 12), (13, 13), (13, 14)],
         'placeHolder':[],
         'placeHolder':[],
}       

mark=Mark()
fielDim=(17,17)
field=generateField(fielDim)
obstacles=presets['nothing'][:]
canvas={}
for tile in field:
    canvas[tile]='Clear'

for obstacle in obstacles:
    if obstacle in presets['border']:
        color=(0,0,255)
    else:
        color=(0,255,0)
    canvas[obstacle]=color

print('\033[2J')

key=''
wasd={'W':(0,-1),'S':(0,1),'A':(-1,0),'D':(1,0)}
ijkl={'I':(0,-1),'K':(0,1),'J':(-1,0),'L':(1,0)}
tfgh={'T':(0,-1),'G':(0,1),'F':(-1,0),'H':(1,0)}
while key!='§':
    clear_eprint()
    ### INPUT ###
    if key in wasd:
        tarXY=translate(mark.xy,wasd[key])
        if isInBounds(tarXY):
            mark.xy=tarXY
    else:
        match key:
            case '`':
                restart()
            case 'P':
                eprint(obstacles)
            case ' ':
                if mark.xy in obstacles:
                    obstacles.remove(mark.xy)
                    canvas[mark.xy]='Clear'
                else: 
                    obstacles.append(mark.xy)
                    canvas[mark.xy]=mark.color
            case 'Q':
                area=getArea(mark.xy)
                for i in area:
                    canvas[i]='Clear'
            case 'E':
                area=getArea(mark.xy)
                for i in area:
                    canvas[i]=mark.color
            case 'R':
                areas=[]
                for node,color in zip(adjacent(mark.xy),[(255,0,0),(0,255,0),(0,0,255),(255,255,255)]):
                    area=getArea(node)
                    for i in area:
                        canvas[i]=color
            case '=':# +
                mark.shiftColor(1)
            case '-':
                mark.shiftColor(-1)
    ### DRAW ###
    ## FIELD ##
    drawField(field)

    ## PALETTE ##
    x=20
    for y,color in enumerate(mark.palette):
        if mark.color==color:
            content='>  <'
        else:
            content='    '
        drawAt(content,(x*2-1,y))
        drawPixelAt(color,(x,y))

    ## CANVAS ##
    for pixel,color in canvas.items():
        if color=='Clear':
            drawFieldTile(pixel)
        else:
            content='::'if pixel in obstacles else '  '
            drawPixelAt(color,pixel,content)

    ## MARK ##
    if canvas[mark.xy]=='Clear':
        mark.draw()
    else:
        mark.draw(canvas[mark.xy])

    key=get_key().upper()


start=(12,9)
finish=(5,5)
while key!='§' or 0:
    clear_eprint()
    if key in ijkl:
        finish=translate(finish,ijkl[key])
    elif key in tfgh:
        start=translate(start,tfgh[key])
    elif key in wasd:
        obstacleMark=translate(obstacleMark,wasd[key])
    elif key==' ':
        if obstacleMark in obstacles:
            obstacles.remove(obstacleMark)
        else: 
            obstacles.append(obstacleMark)

    route=Route()
    # route.path,isCollided,isFinished=AI.findTarget(finish,start,0,[],{})

    drawField(field)
    drawSnake(route)
    drawPixelAt((0,255,0),start)
    drawPixelAt((255,0,0),finish)

    drawPixelAt((250,200,255),obstacleMark,"><")
    drawList(obstacles,(0,0,255))
    if obstacleMark in obstacles: drawPixelAt((0,0,255),obstacleMark,"><")
    

    key=get_key().upper()



