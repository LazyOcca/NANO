from random import *

def enput(text=""):
    inp=input(text)
    if repr(inp)==repr('\x1b'):exit()
    return inp

def intput(text="",default=0): 
    inp=enput(text)
    if not inp.isdigit(): inp=default
    return int(inp)

yesList = ['true','1','yes','yep','o','y','ye','yea','yeah','ya',*['ya'+'s'*s for s in range(10)]]
while True: #loops/game
    #lowNum,highNum = 1,10
    lowNum,highNum = intput("What is the lowest?\n"),intput("\nWhat is the highest?\n")
    anger=""
    print()
    while highNum <= lowNum: #loops/turn
        anger+="!"
        print(highNum,"is not bigger than",str(lowNum)+anger,"\ntry again")
        lowNum,highNum = intput("What is the lowest?\n"),intput("\nWhat is the highest?\n")
        print()
        if highNum > lowNum:
            if len(anger)==1:
                print("Well done!",highNum,"is bigger than",str(lowNum)+".")
            else:
                print("Finally after",len(anger),"tries you got it,",highNum,"is in fact bigger than",str(lowNum)+"...")


    peekMode=False
    totalTries=intput("How many tries do you give yourself? (default is 3) ",default=3)
    if totalTries < 1: 
        print("Can't be lower than 1 you silly. Now you only have 1 try, goodluck.")
        totalTries=1

    print("\nOkay lets start.\n\n")
    theNum=randint(int(lowNum),int(highNum))
    hasWon=False
    for tries in range(1,totalTries+1):
        if hasWon: continue
        if peekMode: print("(psstt the number is",str(theNum)+")")
        print("Guess the number between",lowNum,"and",str(highNum)+". (you have",totalTries-tries+1,"tries left)")
        guess=intput()
        if guess == theNum:
            hasWon=True
        else:
            print("\nwhomp whomp. The number was not",str(guess)+". Lets try again.")
    
    print('\n\n')
    if hasWon:
        print("Yeeyy you did it! you guessed the right number, it was",str(theNum)+".")
    else:
        print(f"You lost. The number was {theNum}")

    wantsToPlayAgain = enput("Want to play again?\n").lower() in yesList

    if wantsToPlayAgain:...
    else: break

